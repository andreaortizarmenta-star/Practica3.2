# Práctica 3.2 AOA — Catálogo de Productos con Tarjetas, Detalle y CRUD en SQLite (.NET MAUI)

Aplicación móvil multiplataforma desarrollada en **.NET MAUI (C# / XAML)** que integra en una sola solución:
- **Catálogo con tarjetas reutilizables** mediante `CollectionView`, `DataTemplate` y `Binding`.
- **Navegación con parámetros** en `Shell` hacia la vista de detalle/formulario (`ProductoDetallePage`).
- **Persistencia local con SQLite** (`sqlite-net-pcl`) para operaciones **CRUD** (Crear, Consultar, Actualizar y Eliminar).
- **Selección de imágenes** tanto integradas en `Resources/Images` como desde la galería del dispositivo (`MediaPicker`).

## Estructura del proyecto

- `Models/Producto.cs`: Modelo de tabla `[Table("Productos")]` con llave primaria autoincremental, almacenamiento de importe en centavos (`PrecioCentavos`) y propiedad calculada `FotoVisible`.
- `Services/ProductosSqlite.cs`: Conexión asíncrona a `catalogo.db3` en `FileSystem.AppDataDirectory`, carga inicial controlada por `PRAGMA user_version` y métodos CRUD.
- `Services/FotosProducto.cs`: Gestión de vista previa temporal en `CacheDirectory`, validación de formato/tamaño (JPG/PNG hasta 15 MB) y almacenamiento en `AppDataDirectory/fotos_productos`.
- `ViewModels/CatalogoViewModel.cs`: Exposición de `ObservableCollection<Producto>` para actualización dinámica de la interfaz.
- `MainPage.xaml` / `MainPage.xaml.cs`: Pantalla principal con botón `+ Agregar producto` y lista de tarjetas desplazable.
- `Views/ProductoDetallePage.xaml` / `Views/ProductoDetallePage.xaml.cs`: Formulario unificado para alta, edición, selección de foto y eliminación de productos.

## Notas técnicas de la práctica

1. **Reutilización de diseño en XAML:** `CollectionView` utiliza un único `DataTemplate` como plantilla y genera una tarjeta por cada objeto de la colección `Productos` mediante `Binding`, evitando duplicar código XAML.
2. **Distinción entre Insertar y Actualizar:** Al abrir el formulario desde `+ Agregar producto`, `Id` vale `0` y se ejecuta `Insertar`; al tocar una tarjeta existente, `ApplyQueryAttributes` recibe el objeto con `Id > 0` y ejecuta `Actualizar`.
3. **Almacenamiento de datos e imágenes:** La base de datos `catalogo.db3` reside en `FileSystem.AppDataDirectory`. La columna `Foto` almacena únicamente el nombre del archivo (texto), mientras que las fotografías seleccionadas de la galería se copian a `AppDataDirectory/fotos_productos` con el prefijo `producto_`.
