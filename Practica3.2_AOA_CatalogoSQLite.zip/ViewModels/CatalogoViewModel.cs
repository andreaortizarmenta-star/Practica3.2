﻿using System.Collections.ObjectModel;
using Practica3_2_AOA.Models;
using Practica3_2_AOA.Services;

namespace Practica3_2_AOA.ViewModels;

public class CatalogoViewModel
{
    public ObservableCollection<Producto> Productos { get; } = new();

    public async Task CargarAsync()
    {
        var productos = await ProductosSqlite.Instancia.Consultar();
        Productos.Clear();
        foreach (var producto in productos)
            Productos.Add(producto);
    }
}
