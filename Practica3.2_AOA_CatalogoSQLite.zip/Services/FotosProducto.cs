﻿namespace Practica3_2_AOA.Services;

public static class FotosProducto
{
    private const long MaxBytes = 15 * 1024 * 1024; // 15 MB
    private const string PrefijoPropia = "producto_";
    private static readonly string CarpetaFotos =
        Path.Combine(FileSystem.AppDataDirectory, "fotos_productos");

    public static bool EsFotoPropia(string? nombreArchivo) =>
        !string.IsNullOrWhiteSpace(nombreArchivo) &&
        nombreArchivo.StartsWith(PrefijoPropia, StringComparison.OrdinalIgnoreCase);

    public static string Resolver(string? foto)
    {
        if (string.IsNullOrWhiteSpace(foto))
            return string.Empty;

        if (EsFotoPropia(foto))
            return Path.Combine(CarpetaFotos, foto);

        return foto;
    }

    public static async Task<string?> ElegirAsync()
    {
        var archivo = await MediaPicker.Default.PickPhotoAsync(new MediaPickerOptions
        {
            Title = "Selecciona una foto del producto"
        });

        if (archivo is null)
            return null;

        var ext = Path.GetExtension(archivo.FileName).ToLowerInvariant();
        if (ext is not (".jpg" or ".jpeg" or ".png"))
            throw new InvalidOperationException("Solo se permiten imágenes JPG, JPEG o PNG.");

        await using var origen = await archivo.OpenReadAsync();
        if (origen.CanSeek && origen.Length > MaxBytes)
            throw new InvalidOperationException("La imagen no debe superar los 15 MB.");

        var nombreTemp = $"preview_{Guid.NewGuid():N}{ext}";
        var rutaTemp = Path.Combine(FileSystem.CacheDirectory, nombreTemp);

        long totalLeido = 0;
        await using (var destino = File.Create(rutaTemp))
        {
            var buffer = new byte[81920];
            int leidos;
            while ((leidos = await origen.ReadAsync(buffer)) > 0)
            {
                totalLeido += leidos;
                if (totalLeido > MaxBytes)
                {
                    destino.Close();
                    File.Delete(rutaTemp);
                    throw new InvalidOperationException("La imagen no debe superar los 15 MB.");
                }
                await destino.WriteAsync(buffer.AsMemory(0, leidos));
            }
        }

        return rutaTemp;
    }

    public static async Task<string> GuardarAsync(string rutaTemporal)
    {
        if (string.IsNullOrWhiteSpace(rutaTemporal) || !File.Exists(rutaTemporal))
            throw new FileNotFoundException("No se encontró la imagen temporal seleccionada.");

        Directory.CreateDirectory(CarpetaFotos);

        var ext = Path.GetExtension(rutaTemporal).ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(ext)) ext = ".jpg";

        var nombreFinal = $"{PrefijoPropia}{Guid.NewGuid():N}{ext}";
        var rutaFinal = Path.Combine(CarpetaFotos, nombreFinal);

        await using (var origen = File.OpenRead(rutaTemporal))
        await using (var destino = File.Create(rutaFinal))
        {
            await origen.CopyToAsync(destino);
        }

        return nombreFinal;
    }

    public static void EliminarSiEsPropia(string? nombreArchivo)
    {
        if (!EsFotoPropia(nombreArchivo))
            return;

        try
        {
            var ruta = Path.Combine(CarpetaFotos, nombreArchivo!);
            if (File.Exists(ruta))
                File.Delete(ruta);
        }
        catch
        {
            // Ignorar errores al limpiar archivos antiguos
        }
    }
}
