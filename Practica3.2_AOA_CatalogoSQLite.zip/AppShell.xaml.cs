﻿using Practica3_2_AOA.Views;

namespace Practica3_2_AOA;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute("producto-detalle", typeof(ProductoDetallePage));
    }
}
